exports.showMechanicList = (req, res, next) => {
    res.render('pages/mechanics-list', {navLocation: 'mechanic'});
}

exports.showMechanicForm = (req, res, next) => {
    res.render('pages/mechanics-form', {});
}

exports.showMechanicInfo = (req, res, next) => {
    res.render('pages/mechanic-info', {});
}

exports.showMechanicEdit = (req, res, next) => {
    res.render('pages/mechanics-edit', {});
}